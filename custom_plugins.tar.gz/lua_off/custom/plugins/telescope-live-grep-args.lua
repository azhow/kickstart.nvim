local pluginspath = vim.fn.stdpath 'config' .. '/plugins/lazy/'
return {
  dir = pluginspath .. 'telescope.nvim',
  dependencies = {
    {
      { dir = pluginspath .. 'telescope-live-grep-args.nvim' },
    },
  },
  config = function()
    require("telescope").load_extension("live_grep_args")
  end
}
