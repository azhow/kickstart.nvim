local pluginspath = vim.fn.stdpath 'config' .. '/plugins/lazy/'
return {
  dir = pluginspath .. 'vim-tmux-navigator',
}
