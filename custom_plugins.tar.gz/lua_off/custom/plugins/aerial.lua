local pluginspath = vim.fn.stdpath 'config' .. '/plugins/lazy/'
return {
  dir = pluginspath .. 'aerial.nvim',
  opts = {},
  -- Optional dependencies
  dependencies = {
    { dir = pluginspath .. 'nvim-treesitter' },
    { dir = pluginspath .. 'nvim-web-devicons' },
  },
}
