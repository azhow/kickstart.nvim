local M = {}

M.VERSION = "v1.10.0" -- x-release-please-version
M.MAJOR_VERSION = 1 -- x-release-please-major
M.MINOR_VERSION = 10 -- x-release-please-minor
M.PATCH_VERSION = 0 -- x-release-please-patch

return M
