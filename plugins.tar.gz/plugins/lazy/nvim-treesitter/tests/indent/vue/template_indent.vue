<template>
  Foo
</template>
