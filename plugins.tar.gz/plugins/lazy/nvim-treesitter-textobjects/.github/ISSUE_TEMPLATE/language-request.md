---
name: Language request
about: Request for a new language to be supported
title: ''
labels: enhancement, good first issue, help wanted
assignees: ''

---

**Language informations**

Please paste any useful informations here !
